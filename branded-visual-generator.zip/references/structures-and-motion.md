# Structures and Motion

## Choosing a visual structure

Pick the form that best communicates the concept. Combine forms when useful. Do not force every concept into one diagram.

- Process flows and pipelines
- Before-and-after comparisons
- System architecture diagrams
- Layered structures and component relationships
- Timelines and sequential stages
- Input-process-output illustrations
- Conceptual metaphors and abstract representations
- Data visualizations and comparisons
- Step-by-step educational scenes
- Product or interface illustrations

Show only what the main message needs. Keep labels short, relationships obvious, and complexity proportional to the concept. The structure may change for comprehension; the brand system may not.

## Motion (animations and GIFs only)

Keep the identity constant across every frame.

- Use subtle fades, controlled slides, clean reveals, and restrained scaling.
- Reveal elements in an order that supports understanding.
- Use consistent easing, timing, and movement throughout.
- Keep positions stable unless movement carries meaning.
- Avoid bouncing, flashing, spinning, abrupt cuts, and distracting effects.
- Keep typography, colors, margins, and element sizes constant.
- The motion must be understandable without audio.
- Make the loop seamless when the use case calls for one.

**GIF defaults:** 16:9 canvas, about 8–15 seconds, 15–24 FPS, unless the user specifies otherwise.

Static images follow the same hierarchy, balance, and consistency rules, with no motion cues.
