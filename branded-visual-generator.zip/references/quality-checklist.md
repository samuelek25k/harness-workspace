# Quality Checklist

## Before delivering, verify all ten

1. The requested concept is represented clearly and accurately.
2. The visual follows the brand system in `brand-system.md`.
3. Spacing, margins, alignment, and proportions are consistent.
4. Typography is readable and hierarchically structured.
5. Colors and icons follow the palette (run `scripts/check_palette.py` for SVG/HTML output).
6. The composition is balanced and uncluttered.
7. Nothing overlaps, clips, or looks unintentionally distorted.
8. Animation, if present, is smooth and consistent.
9. The main message is clear without extra explanation.
10. The asset fits the rest of the series.

If any item fails, refine the composition before delivering.

## Content accuracy

- Represent the concept faithfully; keep its relationships, dependencies, distinctions, and sequences.
- Do not invent facts, metrics, unsupported claims, or technical behavior.
- Match terminology to the audience.
- Check that arrows, labels, and symbols mean what they are meant to mean.
- Simplify without changing the essential meaning.

For abstract concepts, use a clear visual metaphor. For technical concepts, prioritize structural accuracy. For business concepts, prioritize clarity and decision relevance.

## Series consistency

**Fixed across every output:** logo placement, palette and color usage, typography and hierarchy, grid, margins, spacing, shape language, icon style, line weights, corner radii, visual effects, motion language, and overall polish.

**Free to vary:** subject, illustrations, diagrams, metaphors, content and labels, composition when required, number of components or scenes, static vs. animated format, and aspect ratio when explicitly requested.

## Edge cases

- **Missing optional inputs:** use defaults (static 16:9, general audience). Mention an assumption in one short line only if it materially changes the result.
- **Request to change the brand:** explain that the series depends on a fixed identity. Offer to update the Brand Reference Sheet values for the whole series rather than changing one asset alone.
- **Concept too large for one visual:** split it into a short series that shares one identity, and say so.
- **Format conflicts with brand rules** (for example, a GIF with flashing effects): keep the brand and adapt the motion to `structures-and-motion.md`.
