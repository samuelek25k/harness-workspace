# Brand System

Apply this identity to every asset. If a Brand Reference Sheet is supplied, its exact values (logo, HEX codes, font names, spacing tokens) override the defaults below. The HEX values in `palette.json` are placeholders until the user's real values are confirmed.

## Identity

- **Aesthetic:** elegant, modern, minimal, premium, refined, professional.
- **Philosophy:** clarity over decoration, simplicity over clutter, meaningful visuals over complexity.
- **Personality:** intelligent, trustworthy, calm, sophisticated, precise.

## Color

- Base: deep navy or clean off-white.
- Primary accent: blue.
- Secondary accent: teal.
- Neutrals: balanced grays.
- Red, orange, or other attention colors only for meaningful emphasis.

## Typography

- One highly legible sans-serif family across the whole series.
- Clear hierarchy for headings, supporting text, labels, and technical annotations.

## Shapes and icons

- **Sharp edges:** square corners by default. Use radius 0 for panels and diagram nodes; radius 4px only where a soft edge is needed (chips, tokens). Never above 6px.
- Accent marks are crisp: a flat 8px colour bar on one side of a card, 2px hairline borders in gray-300, no shadows.
- **Icons:** one line style from `scripts/icons.py` (names: text, model, token, output, shield, lock, check, cross, arrow, doc, key, eye, branch, flow). Stroke weight is 2px at 24-unit grid, square caps, mitred joins, no fills. Never mix icon sets.
- Icons sit in a 48px square at the top-left of a card, in the card's accent colour, and never carry a label of their own (the card title names it).
- Use at most one icon per card and no more than four per visual.

## Depth and effects

- No shadows, gloss or gradients on cards. Depth comes from the colour bar, the hairline border and the tint of the surface.
- Visual enrichment is allowed when it carries structure: a faint 8px dot or line grid on the background (gray-100 on off-white, navy-raised on navy), numbered step markers (teal square with off-white numeral), thin corner ticks marking a frame, and one teal glow at 10-12% opacity behind a focal element on dark surfaces.
- No random doodles, sparkles, hand-drawn strokes or texture noise.

## Logo placement

- Fixed position and size, with generous whitespace around it.

## Layout

- 16:9 canvas unless the requested format needs another.
- Consistent outer margins and safe areas.
- 8px base spacing, scaled in consistent increments.
- Every component aligned to one common grid.
- Consistent padding, corner radii, stroke weights, and component proportions.
- One clear focal point and a deliberate visual hierarchy.
- Whitespace is intentional. Do not fill empty space just because it exists.
- All text and key elements inside the canvas, readable at the intended display size.
