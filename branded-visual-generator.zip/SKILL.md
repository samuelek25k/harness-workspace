---
name: branded-visual-generator
description: Generate branded visual assets (static images, infographics, diagrams, architecture visuals, blog banners, looping GIFs/MP4) about any user-supplied concept in one permanent minimal identity with sharp edges and line icons. Use whenever the user wants a diagram, infographic, explainer, process flow, architecture visual, banner, or animated GIF, especially for brand consistency, a visual series, "our style", or the same look as previous visuals, even if they never say "branded".
---

# Branded Visual Generator

This skill is self-contained: every rule and value it needs is below. Do not look for reference or asset files; if one is mentioned, ignore it and use what is written here. Build with Python + Pillow (`pip install pillow`), and ffmpeg for animation.

The concept changes each time; the brand and quality bar never do. Do not trade spacing, clarity or consistency for decoration. Keep outputs and replies lean.

## Workflow

1. **Define the concept.** Identify components, relationships and sequence first. Default: static 16:9 image for a general audience. Do not assume the topic is technical.
2. **Pick a structure:** flow, architecture, timeline, comparison or metaphor. Show only what the main message needs.
3. **Build at 2x** (draw at double size, then `resize` down with LANCZOS for crisp edges).
4. **Verify the composition.** Render, then look at the output: overlaps, clipped text, icon alignment, contrast, palette use.
5. **Deliver.** Save to outputs, send the file, reply in one or two sentences. Do not list the checks.

No invented facts or metrics. If a visual shows a worked example (e.g. masking a prompt), compute it with real code and assert the result.

## Colour palette

Use only these colours.

| Role | Name | HEX |
|---|---|---|
| Dark base | navy | #0B1F3A |
| Raised dark panel | navy-raised | #0F2A4D |
| Glow / dark border | navy-glow | #133A5E |
| Light base | off-white | #F7F9FC |
| Light surface | gray-100 / gray-50 | #F0F4F8 / #EEF3FA |
| Surface | white | #FFFFFF |
| Primary accent | blue | #1E6FD9 |
| Blue tint | blue-tint | #DCE9FA |
| Blue on dark (labels) | blue-on-dark | #8DB8F2 |
| Blue chip on dark | blue-deep | #17335A |
| Secondary accent | teal | #14A3A3 |
| Body text | gray-900 | #1F2933 |
| Labels | gray-600 | #52606D |
| Hairlines, subtitles on dark | gray-300 | #CBD2D9 |
| Emphasis (sparingly) | orange | #E07A1F |
| Orange tint | orange-tint | #FCE6D2 |
| Errors only | red | #D64545 |

**Meaning stays fixed within one visual:** orange = raw or sensitive data, blue = masked or tokenised, teal = restored, safe, or focal.

**Text:** on dark, off-white titles and gray-300 subtitles; on light, navy titles and gray-900 body.

**Surfaces:** dark visuals use navy with a faint 48px grid in navy-raised. Light visuals use off-white with a faint 48px grid in gray-50.

## Type

- **Plus Jakarta Sans** (weights 400-800) for all text. **JetBrains Mono** for tokens, code and data.
- Load fonts in Pillow from `.ttf` or `.woff` files; if the brand fonts are not available, fall back to the closest installed sans-serif and say so in one line.
- Web-font subsets often lack arrows and check marks. Draw them as shapes.
- Keep text inside its box (measure with `ImageDraw.textlength`), and keep hierarchy to three sizes: title, body, label.

## Sharp edges

- Square corners by default: cards, panels and diagram nodes have radius 0. Small chips and tokens may use radius 4px. Never above 6px.
- Accent is a flat 8px colour bar on one side of a card, not a rounded border.
- Borders are 2px gray-300 (light) or navy-glow (dark). No shadows, gradients or gloss.
- Arrows are straight lines with a solid triangular head. Use curves only for a deliberate loop.

## Icons

One line style: 2px stroke on a 24-unit grid, square caps, mitred joins, no fills. Draw each icon with this helper (scale by `size / 24` and multiply by the 2x factor):

```python
def icon(d, name, x, y, size=40, colour=(31,41,51), scale=2, stroke=2.0):
    k = size / 24
    P = lambda a, b: ((x + a * k) * scale, (y + b * k) * scale)
    w = max(1, round(stroke * k * scale))
    L = lambda pts: d.line([P(*p) for p in pts], fill=colour, width=w, joint='curve')
    R = lambda a, b, c, e: d.rectangle([P(a, b), P(c, e)], outline=colour, width=w)
    shapes = {
        'shield': lambda: L([(12,3),(20,6),(20,12),(19,16),(12,21),(5,16),(4,12),(4,6),(12,3)]),
        'check':  lambda: L([(4,12),(9,17),(20,6)]),
        'arrow':  lambda: (L([(3,12),(20,12)]), L([(14,6),(20,12),(14,18)])),
        'text':   lambda: (R(5,3,19,21), L([(8,9),(16,9)]), L([(8,13),(16,13)]), L([(8,17),(13,17)])),
        'doc':    lambda: (L([(6,3),(14,3),(19,8),(19,21),(6,21),(6,3)]), L([(14,3),(14,8),(19,8)])),
        'model':  lambda: (R(7,7,17,17), L([(10,3),(10,7)]), L([(14,3),(14,7)]), L([(10,17),(10,21)]), L([(14,17),(14,21)]), L([(3,10),(7,10)]), L([(3,14),(7,14)]), L([(17,10),(21,10)]), L([(17,14),(21,14)])),
        'token':  lambda: (R(3,9,9,15), R(10.5,9,16.5,15), R(18,9,21,15)),
        'output': lambda: (L([(3,6),(3,18)]), L([(3,12),(13,12)]), L([(10,9),(13,12),(10,15)]), L([(17,6),(21,6)]), L([(17,12),(21,12)]), L([(17,18),(21,18)])),
        'lock':   lambda: (R(5,11,19,21), L([(8,11),(8,7),(16,7),(16,11)])),
        'eye':    lambda: (L([(2,12),(6,7),(18,7),(22,12),(18,17),(6,17),(2,12)]), d.ellipse([P(10,10),P(14,14)], outline=colour, width=w)),
    }
    shapes[name]()
```

Rules: one icon per card at most, four per visual at most, placed in a 40-48px square at the top-left of the card, in the accent colour, beside the title. Never mix in another icon set.

## Visual enrichment (structure only)

- Faint 48px background grid (see Surfaces).
- Numbered step markers: teal square with an off-white numeral.
- A teal accent bar before a kicker label (e.g. HOW IT WORKS).
- One teal glow behind the focal element on dark surfaces, at 10-12% opacity.
- A hairline rule above one footer takeaway, with a small icon before it.
- Not allowed: doodles, sparkles, hand-drawn strokes, texture noise, stock photos, decorative blobs.

## Layout

- 16:9 canvas (1600x900 for presentations and series; 1400x788 for Medium banners).
- 8px grid. Outer margin 80px. One clear focal point per visual.
- Whitespace is intentional; do not fill it just because it exists.

## Personal brand: avatar badge (@samuelj90)

Default ON for branded visuals. **OFF when the user says "no branding"** (e.g. Medium banners).

- Badge: circular, teal #14A3A3 ring about 4.5% of its diameter, pale #F0F4F8 disc, with the flat cartoon portrait cropped from the face to the collar so the shirt fills the bottom of the circle. The cartoon portrait is the brand avatar; the real photo is too busy at badge size.
- The badge image is not stored in this skill. If the user has not attached the avatar in this conversation, ask for it once and build the badge from it. If the user does not want to supply it, skip the badge and say so in one line.
- Placement: diameter 12% of the shorter side (round to 8px), 4% margin, bottom-right.
- Handle `@samuelj90` beside the badge in Plus Jakarta Sans SemiBold: off-white on dark backgrounds, navy on light. Choose by sampling the background luminance under the handle.
- On animations, stamp the badge on every frame in the same position.

## Animation and export

- Never cross-blend two scenes with different layouts: text overlaps. Transition by **eased fade-out to the background colour, then fade-in** (smoothstep, about 12 steps per half at 40 ms).
- Hold times: 3-4 s for text scenes, 2.5 s for the intro, 4-5 s for the overview. Say so when the loop exceeds 8-15 s.
- Encode with ffmpeg: GIF via `palettegen=stats_mode=full` then `paletteuse=dither=sierra2_4a`. Also export an MP4 (`-c:v libx264 -crf 14 -pix_fmt yuv420p -movflags +faststart`) as the full-quality version.
- Write frames to a temp directory, never to the outputs folder.
- Also deliver a static PNG of the final scene.

## Scope

Skip for plain text explanations, quick unstyled sketches, or edits to unrelated files.
