"""Brand line icons: one style (2px-equivalent stroke, square caps, mitred joins, no fills).

Icons are drawn on a 24-unit grid and scaled, so every icon in a visual shares
stroke weight and geometry. Usage with a Pillow ImageDraw that is already at 2x:
    icon(draw, "shield", x, y, size=48, colour=(20,163,163), scale=2)
Names: text, model, token, output, shield, lock, check, cross, arrow, doc, key, eye, branch, flow.
"""
from PIL import ImageDraw

def _p(x, y, s, o, sc, k):   # 24-unit grid -> pixels
    return ((x * s / 24 + o[0]) * sc, (y * s / 24 + o[1]) * sc)

def icon(d: ImageDraw.ImageDraw, name: str, x: float, y: float, size: float = 48,
         colour=(31, 41, 51), scale: float = 2, stroke: float = 2.0):
    o, s, sc = (x, y), size, scale
    w = max(1, round(stroke / 24 * size * sc))
    P = lambda a, b: _p(a, b, s, o, sc, 24)
    L = lambda pts: d.line([P(*p) for p in pts], fill=colour, width=w, joint="curve")
    R = lambda a, b, c_, e: d.rectangle([P(a, b), P(c_, e)], outline=colour, width=w)
    if name == "shield":
        L([(12, 3), (20, 6), (20, 12)]); L([(12, 3), (4, 6), (4, 12)])
        L([(4, 12), (4, 17), (12, 21), (20, 17), (20, 12)])
        L([(8, 12), (11, 15), (16, 9)])
    elif name == "lock":
        R(5, 11, 19, 21); L([(8, 11), (8, 7), (16, 7), (16, 11)])
    elif name == "check":
        L([(4, 12), (9, 17), (20, 6)])
    elif name == "cross":
        L([(6, 6), (18, 18)]); L([(18, 6), (6, 18)])
    elif name == "arrow":
        L([(3, 12), (20, 12)]); L([(14, 6), (20, 12), (14, 18)])
    elif name == "text":            # document with lines
        R(5, 3, 19, 21); L([(8, 9), (16, 9)]); L([(8, 13), (16, 13)]); L([(8, 17), (13, 17)])
    elif name == "doc":
        L([(6, 3), (14, 3), (19, 8), (19, 21), (6, 21), (6, 3)]); L([(14, 3), (14, 8), (19, 8)])
    elif name == "model":           # chip with pins
        R(7, 7, 17, 17); L([(10, 3), (10, 7)]); L([(14, 3), (14, 7)])
        L([(10, 17), (10, 21)]); L([(14, 17), (14, 21)]); L([(3, 10), (7, 10)]); L([(3, 14), (7, 14)])
        L([(17, 10), (21, 10)]); L([(17, 14), (21, 14)])
    elif name == "token":           # three square tokens in a row
        R(3, 9, 9, 15); R(10.5, 9, 16.5, 15); R(18, 9, 21, 15)
    elif name == "output":          # stacked lines leaving a box
        L([(3, 6), (3, 18)]); L([(3, 12), (13, 12)]); L([(10, 9), (13, 12), (10, 15)])
        L([(17, 6), (21, 6)]); L([(17, 12), (21, 12)]); L([(17, 18), (21, 18)])
    elif name == "key":
        d.ellipse([P(3, 8), P(10, 15)], outline=colour, width=w); L([(10, 12), (21, 12)]); L([(17, 12), (17, 16)])
    elif name == "eye":
        L([(2, 12), (6, 7), (18, 7), (22, 12), (18, 17), (6, 17), (2, 12)]); d.ellipse([P(10, 10), P(14, 14)], outline=colour, width=w)
    elif name == "branch":
        L([(6, 3), (6, 21)]); L([(6, 12), (18, 6)]); d.rectangle([P(3, 2), P(9, 8)], outline=colour, width=w)
        d.rectangle([P(15, 3), P(21, 9)], outline=colour, width=w)
    elif name == "flow":           # three boxes joined by arrows
        R(2, 8, 7, 16); R(17, 8, 22, 16); L([(7, 12), (17, 12)]); L([(14, 9), (17, 12), (14, 15)])
    else:
        raise ValueError(f"unknown icon {name}")
