#!/usr/bin/env python3
"""Check that an SVG or HTML file uses only colors from the brand palette.

Usage:
    python check_palette.py <file> --palette <palette.json>

Exits 0 when every hex color is in the palette (or the emphasis set), 1 when
off-palette colors are found, and 2 on bad input. Standard library only.
"""
import argparse
import json
import re
import sys
from pathlib import Path

HEX_RE = re.compile(r"#(?:[0-9a-fA-F]{3}){1,2}\b")


def normalize(hex_value: str) -> str:
    """Return a lowercase 6-digit hex string such as #0b1f3a."""
    value = hex_value.lower()
    if len(value) == 4:  # #abc -> #aabbcc
        value = "#" + "".join(ch * 2 for ch in value[1:])
    return value


def load_palette(path: Path) -> set[str]:
    data = json.loads(path.read_text(encoding="utf-8"))
    allowed: set[str] = set()
    for group in ("colors", "emphasis"):
        for value in data.get(group, {}).values():
            allowed.add(normalize(value))
    if not allowed:
        raise ValueError("palette has no colors under 'colors' or 'emphasis'")
    return allowed


def find_off_palette(text: str, allowed: set[str]) -> dict[str, int]:
    found: dict[str, int] = {}
    for match in HEX_RE.findall(text):
        color = normalize(match)
        if color not in allowed:
            found[color] = found.get(color, 0) + 1
    return found


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("file", type=Path, help="SVG or HTML file to check")
    parser.add_argument("--palette", type=Path, required=True, help="palette JSON file")
    args = parser.parse_args()

    try:
        allowed = load_palette(args.palette)
        text = args.file.read_text(encoding="utf-8")
    except (OSError, ValueError, json.JSONDecodeError) as err:
        print(f"error: {err}", file=sys.stderr)
        return 2

    off = find_off_palette(text, allowed)
    if not off:
        print("ok: all hex colors are in the palette")
        return 0

    print("off-palette colors found:")
    for color, count in sorted(off.items(), key=lambda item: -item[1]):
        print(f"  {color}  ({count} use{'s' if count != 1 else ''})")
    return 1


if __name__ == "__main__":
    sys.exit(main())
