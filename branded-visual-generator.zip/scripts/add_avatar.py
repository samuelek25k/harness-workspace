#!/usr/bin/env python3
"""Stamp the brand avatar badge (and optional handle) onto an image or every frame of a GIF.

Usage:
    python add_avatar.py <input> <output> [--badge assets/avatar-badge.png]
                         [--handle @samuelj90] [--corner br|bl|tr|tl]

Placement rule (from the brand system): badge diameter = 12% of the canvas's
shorter side, margin snapped to the 8px grid, bottom-right by default. The
handle sits beside the badge in off-white on dark backgrounds, navy on light.
Requires Pillow.
"""
import argparse
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageSequence, ImageStat

NAVY, OFF_WHITE = (11, 31, 58, 255), (247, 249, 252, 255)


def snap8(v: float) -> int:
    return max(8, int(round(v / 8.0)) * 8)


BRAND_FONT = Path(__file__).resolve().parents[2] / "pii-visual" / "fonts" / "plus-jakarta-sans-latin-600-normal.woff"

def load_font(size: int):
    try:
        return ImageFont.truetype(str(BRAND_FONT), size)   # brand font first
    except OSError:
        pass
    for name in ("Inter-SemiBold.ttf", "DejaVuSans-Bold.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default(size=size)


def layout(w, h, corner, handle, font):
    d = snap8(min(w, h) * 0.12)
    m = snap8(min(w, h) * 0.04)
    tw = th = gap = 0
    if handle:
        l, t, r, b = font.getbbox(handle)
        tw, th, gap = r - l, b - t, snap8(d * 0.15)
    x = m if corner[1] == "l" else w - m - d
    y = m if corner[0] == "t" else h - m - d
    tx = x + d + gap if corner[1] == "l" else x - gap - tw
    ty = y + (d - th) // 2
    return d, (x, y), (tx, ty), (tx, ty, tx + tw, ty + th)


def stamp(frame, badge, handle, corner):
    frame = frame.convert("RGBA")
    w, h = frame.size
    font = load_font(max(12, int(min(w, h) * 0.12 * 0.32)))
    d, bpos, tpos, tbox = layout(w, h, corner, handle, font)
    frame.alpha_composite(badge.resize((d, d), Image.LANCZOS), bpos)
    if handle:
        region = frame.crop(tbox).convert("L")
        lum = ImageStat.Stat(region).mean[0]
        colour = NAVY if lum > 140 else OFF_WHITE
        ImageDraw.Draw(frame).text(tpos, handle, font=font, fill=colour, anchor="lt")
    return frame


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--badge", type=Path, default=Path(__file__).resolve().parent.parent / "assets" / "avatar-badge.png")
    ap.add_argument("--handle", default="")
    ap.add_argument("--corner", default="br", choices=["br", "bl", "tr", "tl"])
    a = ap.parse_args()

    badge = Image.open(a.badge).convert("RGBA")
    src = Image.open(a.input)
    if getattr(src, "is_animated", False):
        frames, durations = [], []
        for f in ImageSequence.Iterator(src):
            durations.append(f.info.get("duration", src.info.get("duration", 80)))
            frames.append(stamp(f, badge, a.handle, a.corner))
        frames[0].save(a.output, save_all=True, append_images=frames[1:], duration=durations,
                       loop=src.info.get("loop", 0), disposal=2, optimize=False)
        print(f"stamped {len(frames)} frames -> {a.output}")
    else:
        out = stamp(src, badge, a.handle, a.corner)
        if a.output.suffix.lower() in (".jpg", ".jpeg"):
            out = out.convert("RGB")
        out.save(a.output)
        print(f"stamped image -> {a.output}")


if __name__ == "__main__":
    main()
